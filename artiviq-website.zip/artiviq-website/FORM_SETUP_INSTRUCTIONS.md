# 📧 Email Form Setup Instructions for Artiviq Website

## ✅ Current Status
Your Contact and Careers forms are **ready to send emails** to `mail@artiviq.in`!

---

## 🚀 Quick Setup (5 Minutes)

### **Step 1: Get Your Free Web3Forms Access Key**

1. **Visit:** https://web3forms.com/
2. **Enter your email:** `mail@artiviq.in`
3. **Click "Create Access Key"**
4. **Check your email** and copy the Access Key they send you
   - It looks like: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

### **Step 2: Add Your Access Key to the Website**

Open the file: `/src/app/pages/ContactPage.tsx`

Find this line (around line 35):
```typescript
access_key: "YOUR_WEB3FORMS_ACCESS_KEY_HERE",
```

Replace `YOUR_WEB3FORMS_ACCESS_KEY_HERE` with your actual key:
```typescript
access_key: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
```

### **Step 3: That's It! 🎉**

Your forms are now live and will send emails directly to **mail@artiviq.in**

---

## 📋 What's Been Implemented

### ✅ **Contact Form** (`/contact` page)
- ✉️ Sends to: **mail@artiviq.in**
- 📝 Includes: Name, Email, Phone, Subject, Message
- ✨ Features:
  - Real-time validation
  - Loading state during submission
  - Success/Error messages
  - Form resets after successful submission
  - Multi-language support (English, Hindi, Bengali)

### ✅ **Careers Form** (`/careers` page)
- ✉️ Sends to: **mail@artiviq.in**
- 📝 Includes: Name, Email, Phone, Position, Experience, Portfolio, Cover Letter, Resume info
- ✨ Features:
  - Job-specific applications
  - Resume file upload indicator
  - Loading state with spinner
  - Success confirmation
  - Multi-language support

---

## 🔍 How It Works

1. **User fills out the form** on your website
2. **Clicks "Send Message"** or "Submit Application"
3. **Web3Forms API** receives the data
4. **Email is sent** to mail@artiviq.in **instantly**
5. **User sees success message** confirming submission

---

## 📧 Email Format You'll Receive

### **Contact Form Email:**
```
From: [User's Email]
To: mail@artiviq.in
Subject: Contact Form: [User's Subject]

Name: John Doe
Email: john@example.com
Phone: +91 9876543210

Message:
I'm interested in your digital marketing services...
```

### **Careers Form Email:**
```
From: [Applicant's Email]
To: mail@artiviq.in
Subject: Job Application: Digital Marketer

Name: Jane Smith
Email: jane@example.com
Phone: +91 9876543210
Position: Digital Marketer
Experience: 3-5 years
Portfolio: https://janesmith.com

Cover Letter:
I am excited to apply for the Digital Marketer position...

Resume attached: resume.pdf
```

---

## 🛡️ Security & Spam Protection

Web3Forms includes:
- ✅ **Honeypot protection** (blocks spam bots)
- ✅ **reCAPTCHA support** (optional, can be added)
- ✅ **Rate limiting** (prevents abuse)
- ✅ **Email validation**
- ✅ **Secure API endpoints**

---

## 🎨 User Experience Features

### **Loading States:**
- Contact Form: "Sending..." button text
- Careers Form: Animated spinner icon

### **Success Messages:**
- ✅ Green confirmation message
- ✅ Form automatically clears
- ✅ Multi-language support

### **Error Handling:**
- ❌ Red error message if submission fails
- 📧 Fallback message: "Please email us directly at mail@artiviq.in"

---

## 📊 Web3Forms Features (FREE Plan)

✅ **Unlimited forms**
✅ **Unlimited submissions**
✅ **Email notifications**
✅ **File upload support** (future upgrade)
✅ **Custom redirect URLs**
✅ **Webhook support**
✅ **No signup required** (just email)
✅ **No branding/watermarks**

---

## 🔧 Testing Your Forms

1. **Go to:** `yourwebsite.com/contact`
2. **Fill out the form** with test data
3. **Submit the form**
4. **Check mail@artiviq.in** for the email (should arrive within seconds)

---

## 🌍 Multi-Language Support

All forms work in:
- 🇬🇧 **English**
- 🇮🇳 **Hindi (हिंदी)**
- 🇧🇩 **Bengali (বাংলা)**

Button text, labels, and messages automatically translate based on user's language selection!

---

## 🚨 Troubleshooting

### **Issue: Not receiving emails**
1. Check your spam/junk folder
2. Verify the Access Key is correct
3. Make sure `to_email: "mail@artiviq.in"` is set correctly
4. Check Web3Forms dashboard for delivery status

### **Issue: Form shows error message**
1. Check browser console for errors (F12)
2. Verify internet connection
3. Try submitting again
4. Contact Web3Forms support if issue persists

### **Issue: Access Key not working**
1. Make sure you copied the entire key
2. No extra spaces before/after the key
3. Check if email verification was completed
4. Generate a new key if needed

---

## 📞 Support

- **Web3Forms Docs:** https://docs.web3forms.com/
- **Web3Forms Support:** support@web3forms.com
- **Alternative:** Can switch to EmailJS, Formspree, or custom backend if needed

---

## 🎯 Next Steps (Optional Enhancements)

### 1. **Add reCAPTCHA** (spam protection)
```typescript
body: JSON.stringify({
  access_key: "your-key",
  // ... other fields
  "g-recaptcha-response": recaptchaToken,
})
```

### 2. **Add Auto-Reply** (confirmation email to user)
```typescript
body: JSON.stringify({
  access_key: "your-key",
  // ... other fields
  from_name: "Artiviq",
  replyto: formData.email,
  autoresponse: "Thank you for contacting Artiviq! We'll respond within 24 hours.",
})
```

### 3. **Custom Thank You Page**
Redirect users to a custom thank you page after submission:
```typescript
body: JSON.stringify({
  access_key: "your-key",
  // ... other fields
  redirect: "https://artiviq.in/thank-you",
})
```

---

## ✨ You're All Set!

Your Artiviq website now has **professional, working contact forms** that send emails directly to your inbox. No backend code, no server management needed! 🎉

**Remember:** Just add your Web3Forms Access Key and you're live!
