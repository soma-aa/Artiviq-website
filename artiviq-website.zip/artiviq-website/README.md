
  # Artiviq (Copy)

  This is a code bundle for Artiviq (Copy). The original project is available at https://www.figma.com/design/gp2nI9XxoDavTlv8ORqTnp/Artiviq--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  